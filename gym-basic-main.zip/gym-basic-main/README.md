Setting up & testing a custom environment in Gym. 

For more info, have a look at my article: 
